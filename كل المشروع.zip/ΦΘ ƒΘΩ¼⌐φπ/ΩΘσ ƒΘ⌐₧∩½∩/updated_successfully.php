<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تم التحديث بنجاح</title>
</head>
<body dir="rtl">
    <h1>تم تحديث بيانات اللاعب بنجاح!</h1>
    <a href="index.html">الرجوع للصفحة الرئيسية</a>
</body>
</html>
