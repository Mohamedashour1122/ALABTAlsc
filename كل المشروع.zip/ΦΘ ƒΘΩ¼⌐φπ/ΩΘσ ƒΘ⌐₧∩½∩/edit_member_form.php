<form action="edit_member.php" method="post">
    <!-- حقول النموذج لتحرير بيانات العضو -->
    <input type="submit" value="Edit Member">
</form>
