<form action="delete_member.php" method="post">
    <!-- حقول النموذج لحذف بيانات العضو -->
    <input type="submit" value="Delete Member">
</form>
