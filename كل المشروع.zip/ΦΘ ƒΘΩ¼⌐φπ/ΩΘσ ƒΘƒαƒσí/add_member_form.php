<form action="add_member.php" method="post">
    <!-- أضف حقول النموذج هنا -->
    <input type="submit" value="Add Member">
</form>
